import { describe, it, expect } from 'vitest'
import { generateToken, generateTokenPromise } from './async-example'

describe('generateToken()', () => {
    it('should generate a token value', ()=> {
        const testuserEmail = 'test@gmail.com'
       
       generateToken(testuserEmail, async (err, token ) => {
         await expect(token).toBeDefined()
       })
    })

    it('should generate asynchronous key', () => {
        const testUserEmail = "test@gmail.com"
        const result = generateTokenPromise(testUserEmail)
        return expect(result).toBeDefined()
    })
})
