import {describe, it, expect} from 'vitest'
import {add} from './math'


describe("Math function", ()=> {
    it("should summarize all numbers values in array", () => {
        //arrange
        const numbers = [1,2,3]

        //act
        const result = add(numbers)

        //assert
        const expectValue = numbers.reduce((acc, cur) => acc + cur, 0)
        expect(result).toBe(expectValue)
    })

    it("should yield NaN if a latest one invalid number is provided", () => {
        //arrange
        const numbersWithInvalidItem = [1,2,3,'generic']

        //Act
        const result = add(numbersWithInvalidItem)

        //assert
        expect(result).toBeNaN()
    })

    it("should yield a correct sum if an array of numeric string values is provided", () => {
        //arrange
        const numbers = ['1', '2', '3']

        //Act
        const result = add(numbers)

        //assert
        const expectValue = numbers.reduce((acc, cur) => +acc + +cur, 0)
        expect(result).toBe(expectValue)
    })

    it("should yield 0 if an empty array is provided", ()=> {
        //arrange
        const numbers = []

        //Act
        const result = add(numbers)

        //assert
        const expectValue = numbers.reduce((acc, cur) => +acc + +cur, 0)
        expect(result).toBe(expectValue)
    })

    it("should throw an error if no value is passed into the function", ()=> {
        const resultFn = () => {
            add()
        }

        expect(resultFn).toThrow()
    })

    it('should throw an error if provided with multiple arguments instead of an array', () => {
        const num1 = 1
        const num2 = 2

        const resultFn = (num1,num2) => add(num1,num2)

        expect(resultFn).toThrow(/is not iterable/)
    })
})