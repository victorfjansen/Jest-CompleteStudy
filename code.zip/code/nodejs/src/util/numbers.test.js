import { describe, expect, it } from "vitest";
import { transformToNumber } from "./numbers";

describe('Number function testing', () => {
    it('should yield a correct number after transform', () => {
        const number = Math.random()*100
        const stringfyNumber = String(number)

        const result = transformToNumber(stringfyNumber)

        expect(result).toBe(number)
    })

    it("should transform a numeric string in a number", () => {
        const numericString = '2'

        const result = transformToNumber(numericString)

        expect(result).toBeTypeOf('number')
    })

    it('should throw an error if empty arguments were provided', () => {
        const resultFn = () => transformToNumber()

        expect(resultFn).toThrow()
    })

    it('should yield NaN if the value provided was not a number', () => {
        const input = 'generic phrase'
        const input2 = {}

        const result = transformToNumber(input)
        const result2 = transformToNumber(input2)

        expect(result).toBeNaN()
        expect(result2).toBeNaN()
    })
})