import { it, describe, expect, vi} from "vitest"
import path from "path"
import {promises as fs} from 'fs'
import writeData from "./io"

vi.mock('fs')
vi.mock('path', () => {
    return {
        default: {
            join: (...args) => args[args.length - 1]
        }
    }
})


describe('writeData()', () => {
    it('should execute writeData correctly and generate a fs', () => {
        const testData = "Test"
        const fileName = "teXt.txt"

        writeData(testData, fileName)

        //return expect(writeData(testData, fileName)).resolves.toBeUndefined()
        //expect(fs.writeFile).toBeCalled()
        expect(fs.writeFile).toBeCalledWith(fileName, testData)
    })

    it('should execute writeData correctly and generate a fs', () => {
        const testData = "Test"
        const fileName = "teXt.txt"

        writeData(testData, fileName)

        return expect(writeData(testData, fileName)).resolves.toBeUndefined()
        //expect(fs.writeFile).toBeCalled()
        //expect(fs.writeFile).toBeCalledWith(fileName, testData)
    })
})