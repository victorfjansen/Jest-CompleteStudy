import { describe, expect, it } from "vitest";
import { extractPostData } from "./posts";

describe("extractPOstData()", () => {
  it("should extract title and content from the provided form data", () => {
    const testTitle = "Test Title";
    const testContent = "Test Content";
    const testFormData = {
      title: testTitle,
      content: testContent,
      get(key) {
        return this[key];
      },
    };

    const { title, content } = extractPostData(testFormData);

    expect(title).toBe(title);
    expect(content).toBe(testContent);
    expect(title).toMatch(String);
  });
});
