import { beforeEach, describe, expect, it } from "vitest";
import { HttpError, ValidationError } from "./errors";

describe("HttpErrorClass", () => {
  it("should initialize with correct data than was provided", () => {
    const statusCode = "genericInfo";
    const message = "genericMessage";
    const data = "genericData";

    const testError = new HttpError(statusCode, message, data);

    expect(testError.statusCode).toBe(statusCode);
    expect(testError.message).toBe(message);
    expect(testError.data).toBe(data);
  });

  it("should contain undefined as data if data was not provided", () => {
    const statusCode = 404;
    const message = "generic Message";

    const testError = new HttpError(statusCode, message);

    expect(testError.statusCode).toBe(statusCode);
    expect(testError.message).toBe(message);
    expect(testError.data).toBeUndefined();
  });
});

describe("ValidationErrorClass", () => {
  it("should container the message that was proviaded", () => {
    const inputMessage = "Generic Message";

    const validationError = new ValidationError(inputMessage);

    expect(validationError.message).toBe(inputMessage);
  });

  it("should yield an undefined if message was not provided", () => {
    const validationError = new ValidationError();

    expect(validationError.message).toBeUndefined();
  });
});
