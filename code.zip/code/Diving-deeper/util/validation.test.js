import { describe, it, expect } from "vitest";
import { validateNotEmpty } from "./validation";

describe("validateNotEmpty()", () => {
  it("should throw an error - with errorMessage value - if text value was an empty string", () => {
    const emptyTextInput = "";
    const errorMessage = "generic error message";

    const resultFn = () => validateNotEmpty(emptyTextInput, errorMessage);

    expect(resultFn).toThrow(/generic error message/);
  });

  it("should throw an error - with errorMessage value - if text value was nos provided", () => {
    const errorMessage = "generic error message";

    const resultFn = () => validateNotEmpty(undefined, errorMessage);

    expect(resultFn).toThrow(/generic error message/);
  });

  it("should not throw an error if text exists and be provided not empty", () => {
    const textInput = "generic text";
    const errorMessage = "generic error message";

    const resultFn = () => validateNotEmpty(textInput, errorMessage);

    expect(resultFn).not.toThrow();
  });
});
