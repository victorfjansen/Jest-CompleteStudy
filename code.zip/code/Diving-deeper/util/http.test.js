import { describe, expect, it, vi } from "vitest";
import { HttpError } from "./errors";
import { sendDataRequest } from "./http";

const testResponseData = { testKey: "testData" };

const testFetch = vi.fn((url, options) => {
  return new Promise((res, rej) => {
    if (typeof options.body !== "string") return rej("Not a string!");
    const testResponse = {
      ok: true,
      json() {
        return new Promise((res, rej) => res(testResponseData));
      },
    };
    res(testResponse);
  });
});

vi.stubGlobal("fetch", testFetch);

describe("sendDataRequest()", () => {
  it("should return any available response data", () => {
    const data = { key: "test" };
    return expect(sendDataRequest(data)).resolves.toEqual(testResponseData);
  });

  it("should convert the provided data to JSON before sending the request", async () => {
    const data = { key: "test" };

    return expect(sendDataRequest(data)).resolves.not.toThrow();
    /* let errorMessage;

    try {
      await sendDataRequest(data);
    } catch (error) {
      errorMessage = error;
    }

    expect(errorMessage).not.toBe("Not a string!"); */
  });

  it("should throw an HttpError in case of non-ok response", () => {
    testFetch.mockImplementationOnce((url, options) => {
      return new Promise((res, rej) => {
        if (typeof options.body !== "string") return rej("Not a string!");
        const testResponse = {
          ok: false,
          json() {
            return new Promise((res, rej) => res(testResponseData));
          },
        };
        res(testResponse);
      });
    });

    const data = { key: "test" };

    return expect(sendDataRequest(data)).rejects.toBeInstanceOf(HttpError);
  });
});
