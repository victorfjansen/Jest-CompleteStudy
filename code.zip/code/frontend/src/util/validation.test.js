import { describe, expect, it } from "vitest";
import { validateNumber, validateStringNotEmpty } from "./validation";

describe('Testing validation: Validating Strings', () => {
    it('should throw an error if argument was provided as an empty value', () => {
        const input = ''
        const resultFn = () => validateStringNotEmpty(input)
        expect(resultFn).toThrow()
    })

    it('should throw an error with a message that contain a reason (must not be empty)', ()=> {
        const input = ''
        const resultFn = () => validateStringNotEmpty(input)
        expect(resultFn).toThrow(/must not be empty/)
    })

    it("should throw an error if any other value than a string is provided", () => {
        const inputNum = 1
        const inputObj = {}
        const inputBool = false

        const resultFn = () => validateStringNotEmpty(inputNum)
        const resultFn1 = () => validateStringNotEmpty(inputObj)
        const resultFn2 = () => validateStringNotEmpty(inputBool)

        expect(resultFn).toThrow()
        expect(resultFn1).toThrow()
        expect(resultFn2).toThrow()
    })

    it('should not throw an error if argument provided was a not empty string', () => {
        const input = 'generic string'
        const resultFn =() => validateStringNotEmpty(input)
        expect(resultFn).not.toThrow()
    })
})

describe('Testing validation: Validating Numbers', () => {
    it('should throw an error if provided argument is a non number', () => {
        const inputStr = 'generic string'
        const inputObj = {}

        const resultFn = () => validateNumber(inputStr)
        const resultFn1 = () => validateNumber(inputObj)

        expect(resultFn).toThrow()
        expect(resultFn1).toThrow()
    })

    it('should throw an error if provided argument is empty', () => {
        const resultFn = () => validateNumber()
        expect(resultFn).toThrow()
    })

    it("should throw an error with reason (invalid number input) if the provided argument is not a number", () => {
        const input = 'generic string'
        const resultFn = () => validateNumber(input)
        expect(resultFn).toThrow(/Invalid number input/)
    })

    it('should throw an error if NaN argument was provided', () => {
        const input = NaN
        const resultFn = () => validateNumber(input)
        expect(resultFn).toThrow()
    })
})