import { describe, expect, it } from "vitest";
import { cleanNumbers, transformToNumber } from "./numbers";

describe('tranformToNumber function testing', () => {
    it('should yield a correct number after transform', () => {
        const number = Math.random()*100
        const stringfyNumber = String(number)

        const result = transformToNumber(stringfyNumber)

        expect(result).toBe(number)
    })

    it("should transform a numeric string in a number", () => {
        const numericString = '2'

        const result = transformToNumber(numericString)

        expect(result).toBeTypeOf('number')
    })

    it('should throw an error if empty arguments were provided', () => {
        const resultFn = () => transformToNumber()

        expect(resultFn).toThrow()
    })

    it('should yield NaN if the value provided was not a number', () => {
        const input = 'generic phrase'
        const input2 = {}

        const result = transformToNumber(input)
        const result2 = transformToNumber(input2)

        expect(result).toBeNaN()
        expect(result2).toBeNaN()
    })
})

describe('cleanNumbers function testing', () => {
    it('should return an array of number values if an array of string numbers values is provided', () => {
        const numberValues = ['1', '2']

        const result = cleanNumbers(numberValues)

        expect(result[0]).toBeTypeOf('number')
        expect(result).toEqual([1,2])
    })

    it('should throw an error if an array with a least one empty string is provided', () => {
        const numberValues = ['2', '']

        const cleanFn = () => cleanNumbers(numberValues)

        expect(cleanFn).toThrow()
    })

    it('should throw an error if an array with a least one value is diferent of string is nprovided', () => {
        const invalidArr1 = ['2', true]
        const invalidArr2 = ['2', {}]
        const invalidArr3 = ['2', 3]

        const cleanFn1 = () => cleanNumbers(invalidArr1)
        const cleanFn2 = () => cleanNumbers(invalidArr2)
        const cleanFn3 = () => cleanNumbers(invalidArr3)

        expect(cleanFn1).toThrow()
        expect(cleanFn2).toThrow()
        expect(cleanFn3).toThrow()
    })
})