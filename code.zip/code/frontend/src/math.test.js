import {describe, it, expect} from 'vitest'
import {add} from './math'


describe("Math function", ()=> {
    it("should summarize all numbers values in array", () => {
        const numbers = [1,2,3]
        const result = add(numbers)
        const expectValue = numbers.reduce((acc, cur) => acc + cur, 0)
        expect(result).toBe(expectValue)
    })

    it("should yield NaN if a latest one invalid number is provided", () => {
        const numbersWithInvalidItem = [1,2,3,'generic']
        const result = add(numbersWithInvalidItem)
        expect(result).toBeNaN()
    })

    it("should yield a correct sum if an array of numeric string values is provided", () => {
        const numbers = ['1', '2', '3']
        const result = add(numbers)
        const expectValue = numbers.reduce((acc, cur) => +acc + +cur, 0)
        expect(result).toBe(expectValue)
    })

    it("should yield 0 if an empty array is provided", ()=> {
        const numbers = []
        const result = add(numbers)
        const expectValue = numbers.reduce((acc, cur) => +acc + +cur, 0)
        expect(result).toBe(expectValue)
    })

    it("should throw an error if no value is passed into the function", ()=> {
        const resultFn = () => add()
        expect(resultFn).toThrow()
    })

    it('should throw an error if provided with multiple arguments instead of an array', () => {
        const resultFn = () => add()
        expect(resultFn).toThrow(/is not iterable/)
    })
})